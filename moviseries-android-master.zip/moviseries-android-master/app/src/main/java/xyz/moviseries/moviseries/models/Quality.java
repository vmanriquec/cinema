package xyz.moviseries.moviseries.models;

/**
 * Created by DARWIN on 6/5/2017.
 */

public class Quality {
    private String quality;

    public String getQuality() {
        return quality;
    }
}
