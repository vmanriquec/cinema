package xyz.moviseries.moviseries.models;

/**
 * Created by DARWIN on 10/5/2017.
 */

public class SerieScore extends Serie {
    private String score,votos;


    public String getScore() {
        return score;
    }

    public String getVotos() {
        return votos;
    }
}
