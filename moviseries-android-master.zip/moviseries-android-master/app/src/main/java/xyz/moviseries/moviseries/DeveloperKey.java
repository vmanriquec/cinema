package xyz.moviseries.moviseries;

/**
 * Created by DARWIN on 7/5/2017.
 */

public class DeveloperKey {
    public static final String DEVELOPER_KEY = "AIzaSyAfIpsSux7Uj1fEFTNgwpZn6Y_4ELf8keY";
    public static final String OPENLAOD_API_LOGIN = "a95bf49d84db249b";
    public static final String OPENLAOD_API_KEY = "SBMn8hL_";
}
