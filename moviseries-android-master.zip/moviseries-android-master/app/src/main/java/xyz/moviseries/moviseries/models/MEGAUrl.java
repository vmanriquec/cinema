package xyz.moviseries.moviseries.models;

/**
 * Created by DARWIN on 8/5/2017.
 */

public class MEGAUrl {
    private String mega_id, name,url, movie_id, note, language_name;

    public String getMega_id() {
        return mega_id;
    }

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }

    public String getMovie_id() {
        return movie_id;
    }

    public String getNote() {
        return note;
    }

    public String getLanguage_name() {
        return language_name;
    }
}
