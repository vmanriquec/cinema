package xyz.moviseries.moviseries.api_jsons;

import xyz.moviseries.moviseries.models.Movie;

/**
 * Created by DARWIN on 6/5/2017.
 */

public class JSONLastMovies {
    private Movie movies;

    public Movie getMovies() {
        return movies;
    }
}
