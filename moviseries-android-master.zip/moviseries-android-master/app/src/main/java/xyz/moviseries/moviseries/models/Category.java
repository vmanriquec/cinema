package xyz.moviseries.moviseries.models;

/**
 * Created by DARWIN on 12/5/2017.
 */

public class Category {
    private String category_name;

    public Category(String category_name) {
        this.category_name = category_name;
    }

    public String getCategory_name() {
        return category_name;
    }
}
