package xyz.moviseries.moviseries.models;

/**
 * Created by DARWIN on 10/5/2017.
 */

public class SeasonSerie {


    private String season_id,number,cover,trailer,serie_id,updated_at,key_words;

    public String getNumber() {
        return number;
    }

    public String getSeason_id() {
        return season_id;
    }

    public String getCover() {
        return cover;
    }

    public String getTrailer() {
        return trailer;
    }

    public String getSerie_id() {
        return serie_id;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public String getKey_words() {
        return key_words;
    }
}
