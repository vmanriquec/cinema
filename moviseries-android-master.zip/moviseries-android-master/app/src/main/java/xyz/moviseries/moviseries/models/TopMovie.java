package xyz.moviseries.moviseries.models;

/**
 * Created by DARWIN on 7/5/2017.
 */

public class TopMovie extends Movie {
    private String score;

    public String getScore() {
        return score;
    }
}
