package xyz.moviseries.moviseries.models;

/**
 * Created by DARWIN on 8/5/2017.
 */

public class MovieScore extends Movie {

    private String score,votos;


    public String getScore() {
        return score;
    }

    public String getVotos() {
        return votos;
    }
}
