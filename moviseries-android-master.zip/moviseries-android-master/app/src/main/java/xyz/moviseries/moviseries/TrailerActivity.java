package xyz.moviseries.moviseries;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

/**
 * Created by DARWIN on 7/5/2017.
 */

public class TrailerActivity  extends YouTubeBaseActivity{

    
}
