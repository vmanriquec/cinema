package xyz.moviseries.moviseries;

/**
 * Created by DARWIN on 19/5/2017.
 */

public class ResideManuActivity {
}
