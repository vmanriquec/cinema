package xyz.moviseries.moviseries.models;

/**
 * Created by DARWIN on 7/5/2017.
 */

public class Season {

    private String number, season_id, cover, trailer, serie_name, serie_id;


    public String getNumber() {
        return number;
    }

    public String getSeason_id() {
        return season_id;
    }

    public String getCover() {
        return cover;
    }

    public String getTrailer() {
        return trailer;
    }

    public String getSerie_name() {
        return serie_name;
    }

    public String getSerie_id() {
        return serie_id;
    }
}
